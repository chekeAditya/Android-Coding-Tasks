package com.application.discovermovies.di

class Network {

}